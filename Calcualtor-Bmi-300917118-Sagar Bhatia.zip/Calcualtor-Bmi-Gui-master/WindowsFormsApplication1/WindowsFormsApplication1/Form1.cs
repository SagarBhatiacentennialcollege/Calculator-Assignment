﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            label1.Text = "lbs";
            label2.Text = "inch";
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            label1.Text = "Kg";
            label2.Text = "m";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double height = Convert.ToDouble(textBox1.Text);
            double weight = Convert.ToDouble(textBox2.Text);
            double result;


            if (radioButton1.Checked)
            {

                result = (weight * 703) / (height * height);
                string Result = Convert.ToString(Math.Round(result, 2)) + " - ";
                if (result < 18.5)
                { richTextBox1.Text = Result + " YOU ARE UNDERWEIGHT"; }
                else if (result > 18.5 && result < 24.9)
                { richTextBox1.Text = Result + "YOU ARE NORMAL"; }
                else if (result > 25 && result <= 29.9)
                { richTextBox1.Text = Result + " YOU ARE OVERWEIGHT"; }
                else if (result >= 30)
                { richTextBox1.Text = Result + " YOU ARE OBESE"; }
            }
            else if (radioButton2.Checked)
            {
                result = weight / (height * height);
                string Result = Convert.ToString((result) + " - ");

                if (result < 18.5)
                { richTextBox1.Text = Result + "YOU ARE UNDERWEIGHT"; }
                else if (result > 18.5 && result < 24.9)
                { richTextBox1.Text = Result + "YOU ARE NORMAL"; }
                else if (result >= 25 && result <= 29.9)
                { richTextBox1.Text = Result + "YOU ARE OVERWEIGHT"; }
                else if (result >= 30)
                { richTextBox1.Text = Result + "YOU ARE OBESE"; }

            }
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 NewForm = new Form1();
            NewForm.Show();
            this.Dispose(false);
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
